//
//  Contacto.swift
//  Edicion
//
//  Created by Alumno on 10/28/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation

class Contacto {
    
    var nombre : String
    var celular : String
    var correo : String
    var hospital : String
    var asma : String
    var diabetes: String
    var hipo : String
    var hiper : String
    var sobrepeso : String
    var hepatitis : String
    
    init(nombre: String, celular: String, correo: String, hospital: String, asma: String, diabetes: String, hipo : String, hiper : String, sobrepeso : String, hepatitis : String) {
        self.nombre = nombre
        self.celular = celular
        self.correo = correo
        self.hospital = hospital
        self.asma = asma
        self.diabetes = diabetes
        self.hipo = hipo
        self.hiper = hiper
        self.sobrepeso = sobrepeso
        self.hepatitis = hepatitis
    }
}
