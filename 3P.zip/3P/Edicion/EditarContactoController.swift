//
//  EditarContactoController.swift
//  Edicion
//
//  Created by Alumno on 11/2/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class EditarContactoController: UIViewController {
    
    var contacto : Contacto?
    var indice :Int?
    
    @IBOutlet weak var txtNombre: UITextField!
    @IBOutlet weak var txtCorreo: UITextField!
    @IBOutlet weak var txtCelular: UITextField!
    
    @IBOutlet weak var txtHospital: UITextField!
    
    @IBOutlet weak var txtHipo: UITextField!
    @IBOutlet weak var txtDiabetes: UITextField!
    @IBOutlet weak var txtHiper: UITextField!
    @IBOutlet weak var txtSobrepeso: UITextField!
    @IBOutlet weak var txtHepatits: UITextField!
    @IBOutlet weak var txtAsma: UITextField!
    
    
    
    var callbackActualizarTVContactos : (() -> Void)?
    var callbackEliminarContacto : ((Int) -> Void)?
    
    
    override func viewDidLoad() {
        self.title = "Editar Paciente"
        
        txtCorreo.text = contacto!.correo
        txtNombre.text = contacto!.nombre
        txtCelular.text = contacto!.celular
        txtHospital.text = contacto!.hospital
        txtSobrepeso.text = contacto!.sobrepeso
        txtHiper.text = contacto!.hiper
        txtHepatits.text = contacto!.hepatitis
        txtDiabetes.text = contacto!.diabetes
        txtAsma.text = contacto!.asma
        txtHipo.text = contacto!.hipo
    }
    
    @IBAction func doTapGuardar(_ sender: Any) {
        contacto!.nombre = txtNombre.text!
        contacto!.correo = txtCorreo.text!
        contacto!.celular = txtCelular.text!
        contacto!.hospital = txtHospital.text!
        contacto!.diabetes = txtDiabetes.text!
        contacto!.asma = txtAsma.text!
        contacto!.hipo = txtHipo.text!
        contacto!.hiper = txtHiper.text!
        contacto!.sobrepeso = txtSobrepeso.text!
        contacto!.hepatitis = txtHepatits.text!
        
        callbackActualizarTVContactos!()
    }
    @IBAction func doTapEliminar(_ sender: Any) {
        callbackEliminarContacto!(indice!)
        self.navigationController!.popViewController(animated: true)
    }
    
}
