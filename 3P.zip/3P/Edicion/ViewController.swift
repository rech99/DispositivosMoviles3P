//
//  ViewController.swift
//  Edicion
//
//  Created by Alumno on 10/28/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return contactos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let celda = tableView.dequeueReusableCell(withIdentifier: "celdaContacto") as! CeldaContactoController
        
        celda.lblNombre.text = contactos[indexPath.row].nombre
        celda.lblCorreo.text = contactos[indexPath.row].correo
        celda.lblCelular.text = contactos[indexPath.row].celular
        celda.lblHospital.text = contactos[indexPath.row].hospital
        
        
        return celda
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "goToEditar" {
            
            let contactoSeleccionado = contactos[tvContactos.indexPathForSelectedRow!.row]
            let destino = segue.destination as! EditarContactoController
            destino.contacto = contactoSeleccionado
            destino.indice = tvContactos.indexPathForSelectedRow!.row
            destino.callbackActualizarTVContactos = actualizarTVContactos
            destino.callbackEliminarContacto = eliminarContacto
            
        }
        
        if segue.identifier == "goToAgregar" {
            
            let destino = segue.destination as! AgregarContactoController
            destino.callbackAgregarContacto = agregarContacto
            
        }
        
        
    }
    
  
    @IBOutlet weak var tvContactos: UITableView!
    var contactos : [Contacto] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Pacientes"
        
        contactos.append(Contacto(nombre: "José", celular: "64459823", correo: "jose14@gmail.com", hospital: "Imss", asma: "Negativo", diabetes: "Positivo", hipo: "Positivo", hiper: "Negativo",   sobrepeso: "Positivo", hepatitis: "Positivo"))
        contactos.append(Contacto(nombre: "Maria", celular: "64420412", correo: "mary@gmail.com", hospital: "Issteson", asma: "Positivo", diabetes: "Positivo", hipo: "Negativo", hiper: "Negativo",   sobrepeso: "Negativo", hepatitis: "Positivo"))
        contactos.append(Contacto(nombre: "Ana", celular: "64363463", correo: "ana03@gmail.com", hospital: "San Jose", asma: "Positivo", diabetes: "Positivo", hipo: "Positivo", hiper: "Negativo",   sobrepeso: "Posititivo", hepatitis: "Positivo"))
        contactos.append(Contacto(nombre: "Pedro", celular: "6432023523", correo: "Pedro@gmail.com", hospital: "Issteson", asma: "Positivo", diabetes: "Positivo", hipo: "Negativo", hiper: "Negativo",   sobrepeso: "Negativo", hepatitis: "Positivo"))
        contactos.append(Contacto(nombre: "Carmen", celular: "644569823", correo: "kkrmen@gmail.com", hospital: "San Jose", asma: "Positivo", diabetes: "Positivo", hipo: "Negativo", hiper: "Negativo",   sobrepeso: "Negativo", hepatitis: "Positivo"))
        contactos.append(Contacto(nombre: "Pablo", celular: "6442059633", correo: "Pablo@gmail.com", hospital: "San Jose", asma: "Positivo", diabetes: "Positivo", hipo: "Negativo", hiper: "Negativo",   sobrepeso: "Negativo", hepatitis: "Positivo"))
        contactos.append(Contacto(nombre: "Felix", celular: "6562059343", correo: "Felix@gmail.com", hospital: "Issteson", asma: "Negativo", diabetes: "Negativo", hipo: "Negativo", hiper: "Negativo",   sobrepeso: "Negativo", hepatitis: "Positivo"))
        contactos.append(Contacto(nombre: "Guadalupe", celular: "64257707", correo: "LaRosa@gmail.com", hospital: "San Jose", asma: "Positivo", diabetes: "Positivo", hipo: "Negativo", hiper: "Negativo",   sobrepeso: "Negativo", hepatitis: "Negativo"))
        contactos.append(Contacto(nombre: "Jorge", celular: "61243763", correo: "Jorge@gmail.com", hospital: "Imss", asma: "Positivo", diabetes: "Positivo", hipo: "Positivo", hiper: "Positivo",   sobrepeso: "Positivo", hepatitis: "Positivo"))
        contactos.append(Contacto(nombre: "Rodrigo", celular: "644257645", correo: "ana03@gmail.com", hospital: "Issteson", asma: "Negattivo", diabetes: "Positivo", hipo: "Positivo", hiper: "Positivo",   sobrepeso: "Negativo", hepatitis: "Positivo"))
        
    }
    
    func actualizarTVContactos() {
        tvContactos.reloadData()
    }
    
    func eliminarContacto(indice: Int) {
        contactos.remove(at: indice)
        actualizarTVContactos()
    }
    
    func agregarContacto(contacto: Contacto) {
        contactos.append(contacto)
        actualizarTVContactos()
    }
    
}

