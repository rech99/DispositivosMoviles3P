//
//  AgregarContactoController.swift
//  Edicion
//
//  Created by Alumno on 11/9/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class AgregarContactoController : UIViewController {
    
    @IBOutlet weak var txtNombre: UITextField!
    @IBOutlet weak var txtCelular: UITextField!
    
    @IBOutlet weak var txtHospital: UITextField!
    @IBOutlet weak var txtDiabetes: UITextField!
    @IBOutlet weak var txtAsma: UITextField!
    @IBOutlet weak var txtHepatitis: UITextField!
    @IBOutlet weak var txtSobrepeso: UITextField!
    @IBOutlet weak var txtHipo: UITextField!
    @IBOutlet weak var txtHiper: UITextField!
    @IBOutlet weak var txtCorreo: UITextField!
    
    var callbackAgregarContacto : ((Contacto) -> Void)?
    
    override func viewDidLoad() {
        self.title = "Agregar Paciente"
    }
    
    @IBAction func doTapGuardar(_ sender: Any) {
        let contacto = Contacto(nombre: txtNombre.text!, celular: txtCelular.text!, correo: txtCorreo.text!, hospital: txtHospital.text!,asma: txtAsma.text!, diabetes:   txtDiabetes.text!, hipo: txtHipo.text!, hiper: txtHiper.text!,  sobrepeso: txtSobrepeso.text!, hepatitis: txtHepatitis.text! )
        callbackAgregarContacto!(contacto)
        
        self.navigationController?.popViewController(animated: true)
        
        
    }
    
}
